#include <utility.h>
#include <ansi_c.h>
#include <cvirte.h>		
#include <userint.h>
#include "demo.h"
//////////////////////////
/*********************************
**
**  VISA-IO-�޸�ʽ
**
*********************************/
//#define USE_TDS2012  //
#define USE_DSO5012  //

#include <visa.h>
#include <stdio.h>
//#include "visaudpcom.h"

//#define RESOURCE "TCPIP0::192.168.10.108::inst0::INSTR"
#define RESOURCE "TCPIP0::169.254.4.61::inst0::INSTR"
ViStatus   status;	  //����״̬����
ViSession  defRM;	  //����ϵͳ��Դ�Ự����
ViSession  instr;	  //���������Ự����


int cnt; //�������������
char inbuf[128];  //�������뻺����
char outbuf[128]; //�������������
ViSession defaultRM;	//����ϵͳĬ����Դ
ViSession vi;	//���������Ự
void Initialize(void);

//��������
int fuc_rst(void);//��λ����
int fuc_idn(void);//��ʾ��Ϣ����
int fuc_freq(void);
int fuc_ampl(void);
char idbuf[100]= {0};
int mod_freq=0;
int para_freq=0;
int mod_ampl=0;
int para_ampl=0;
static int panelHandle;
int continuous = 0;
int mode = 0;
int	Start_Stop_Flag = 0;
int modef=4; 
#define DISPDATALEN 2500
int XData[DISPDATALEN];	
int YData[DISPDATALEN];
double res;
double freq;
double dci;
double aci;
double acv;
double dcv;
double cap;
int istart;//ƫ�Ƶ�λƫ�����ĸ������趨��λƫ����Ϊ3.14/180��
///////////////////////////
int main (int argc, char *argv[])
{
	int i;
	for(i=0;i<DISPDATALEN;i++)
	{
		XData[i]=i;
	}
    istart = 0;
	if (InitCVIRTE (0, argv, 0) == 0)
		return -1;	/* out of memory */
	if ((panelHandle = LoadPanel (0, "demo.uir", PANEL)) < 0)
		return -1;
	DisplayPanel (panelHandle);
	RunUserInterface ();
	DiscardPanel (panelHandle);
	return 0;
}

  int CVICALLBACK main_callback (int panel, int event, void *callbackData,
								 int eventData1, int eventData2)
  {
	  switch (event)
	  {
		  case EVENT_GOT_FOCUS:

			  break;
		  case EVENT_LOST_FOCUS:

			  break;
		  case EVENT_CLOSE:
			   QuitUserInterface(0);
			  break;
	  }
	  return 0;
  }
//��ʼ������λ��IDN
void Initialize(void)
{
	viPrintf(vi,":AUTOSCALE\n");
}
int fuc_rst(void)	  
{
	viOpenDefaultRM(&defaultRM);
	viOpen(defaultRM,RESOURCE,VI_NULL,VI_NULL,&vi);
	viClear(vi);
		viPrintf(vi,"*RST\n");
    viClose(vi);
	viClose(defaultRM);
	return 0;
}
int fuc_idn(void)	  
{
	viOpenDefaultRM(&defaultRM);
	viOpen(defaultRM,RESOURCE,VI_NULL,VI_NULL,&vi);
	viClear(vi);
		viQueryf(vi, "*IDN?\n", "%t", &idbuf);
		//viPrintf(vi,"*IDN?\n");
		//viScanf(vi, "%t", &idbuf);
    viClose(vi);
	viClose(defaultRM);
	return 0;
}
int CVICALLBACK get_rst (int panel, int control, int event,
						 void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			fuc_rst();
			break;
	}
	return 0;
}

int CVICALLBACK get_idn (int panel, int control, int event,
						 void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			fuc_idn();
			SetCtrlVal(panelHandle,PANEL_IDN_WINDOW,idbuf); 
			break;
	}
	return 0;
}
//��������
double freq; 
int  GetFreq (void)//Ƶ�ʲ���
{
	
	int result=-1;

	viOpenDefaultRM(&defaultRM);
	viOpen(defaultRM,RESOURCE,VI_NULL,VI_NULL,&vi);
	viClear(vi);
	Initialize();
	int rangecnt_freq;//��λ������
	GetCtrlVal(panelHandle, PANEL_RING_5, &rangecnt_freq);
	switch(rangecnt_freq)
		{
    case 0:
	result = viQueryf(vi,":MEASure:FREQ?\n","%lf",&freq);break;
	case 1:
		  result = viQueryf(vi,":MEASure:FREQ? MIN,MAX\n","%lf",&freq);break;
	case 2:
		result = viQueryf(vi,":MEASure:FREQ? DEF,MAX\n","%lf",&freq);break;
	case 3:
		result = viQueryf(vi,":MEASure:FREQ? MAX,MAX\n","%lf",&freq);break;
		}
	if(result == 0)
	{
		//printf("Freq =%f Hz\n",Freq);
	
	}
	else
	{
		//printf("error ,time out \n");
				//error timeout 
	}
	viClose(vi);
	viClose(defaultRM);
	return 0;
}
double dci;  
int Getdci (void)//ֱ����������
{
	int result=-1;
	viOpenDefaultRM(&defaultRM);
	viOpen(defaultRM,RESOURCE,VI_NULL,VI_NULL,&vi);
	viClear(vi);
	Initialize();
	int rangecnt_dci;//��λ������
	GetCtrlVal(panelHandle, PANEL_RING_3, &rangecnt_dci);
	switch(rangecnt_dci)
	{
    case 0:
	result = viQueryf(vi,":MEASure:CURRent:DC?\n","%lf",&dci);break;
	case 1:
	result = viQueryf(vi,":MEASure:CURRent:DC? 0.0001,0.0000000001\n","%lf",&dci);break;
	case 2:
	result = viQueryf(vi,":MEASure:CURRent:DC? 0.001,0.000000001\n","%lf",&dci);break;
	case 3:
		result = viQueryf(vi,":MEASure:CURRent:DC? 0.01,0.00000001\n","%lf",&dci);break;
	case 4:
		result = viQueryf(vi,":MEASure:CURRent:DC? 0.1,0.0000001\n","%lf",&dci);break;
	case 5:
		result = viQueryf(vi,":MEASure:CURRent:DC? 1,0.000001\n","%lf",&dci);break;
	case 6:
		result = viQueryf(vi,":MEASure:CURRent:DC? 3,0.000001\n","%lf",&dci);break;
	}
	viClose(vi);
	viClose(defaultRM);
	return 0;

}
double aci; 
int Getaci (void) //������������
{
	int result=-1;
	viOpenDefaultRM(&defaultRM);
	viOpen(defaultRM,RESOURCE,VI_NULL,VI_NULL,&vi);
	viClear(vi);
	Initialize();
	int rangecnt_aci;//��λ������
	GetCtrlVal(panelHandle, PANEL_RING_3, &rangecnt_aci);
	switch(rangecnt_aci)
	{
    case 0:
	result = viQueryf(vi,":MEASure:CURRent:AC?\n","%lf",&aci);break;
	case 1:
	result = viQueryf(vi,":MEASure:CURRent:AC? 0.0001,0.0000000001\n","%lf",&aci);break;
	case 2:
	result = viQueryf(vi,":MEASure:CURRent:AC? 0.001,0.000000001\n","%lf",&aci);break;
	case 3:
		result = viQueryf(vi,":MEASure:CURRent:AC? 0.01,0.00000001\n","%lf",&aci);break;
	case 4:
		result = viQueryf(vi,":MEASure:CURRent:AC? 0.1,0.0000001\n","%lf",&aci);break;
	case 5:
		result = viQueryf(vi,":MEASure:CURRent:AC? 1,0.000001\n","%lf",&aci);break;
	case 6:
		result = viQueryf(vi,":MEASure:CURRent:AC? 3,0.000001\n","%lf",&aci);break;
	}
	if(result == 0)
	{
		//printf("Freq =%f Hz\n",Freq);
	
	}
	else
	{
		//printf("error ,time out \n");
				//error timeout 
	}
	viClose(vi);
	viClose(defaultRM);
	return 0;

}
double dcv;   
int Getdcv (void) //ֱ����ѹ����
{
	int result=-1;
	viOpenDefaultRM(&defaultRM);
	viOpen(defaultRM,RESOURCE,VI_NULL,VI_NULL,&vi);
	viClear(vi);
	Initialize();
	int rangecnt_dcv;//��λ������
	GetCtrlVal(panelHandle, PANEL_RING_4, &rangecnt_dcv);
	switch(rangecnt_dcv)
	{
		case 0:
	result = viQueryf(vi,":MEASure:VOLTage:DC?\n","%lf",&dcv);break;
		case 1:
	result = viQueryf(vi,":MEASure:VOLTage:DC? 0.1,MAX\n","%lf",&dcv);break;
		case 2:
	result = viQueryf(vi,":MEASure:VOLTage:DC? 1,MAX\n","%lf",&dcv);break;
		case 3:
	result = viQueryf(vi,":MEASure:VOLTage:DC? 10,MAX\n","%lf",&dcv);break;
	    case 4:
	result = viQueryf(vi,":MEASure:VOLTage:DC? 100,MAX\n","%lf",&dcv);break;
		case 5:
	result = viQueryf(vi,":MEASure:VOLTage:DC? 1000,MAX\n","%lf",&dcv);break;
	}
	if(result == 0)
	{
		//printf("Freq =%f Hz\n",Freq);
	
	}
	else
	{
		//printf("error ,time out \n");
				//error timeout 
	}
	viClose(vi);
	viClose(defaultRM);
	return 0;

}
	double acv; 
int Getacv (void) //������������
{
	int result=-1;
	viOpenDefaultRM(&defaultRM);
	viOpen(defaultRM,RESOURCE,VI_NULL,VI_NULL,&vi);
	viClear(vi);
	Initialize();

	int rangecnt_acv;//��λ������
	GetCtrlVal(panelHandle, PANEL_RING_4, &rangecnt_acv);
	switch(rangecnt_acv)
	{
		case 0:
	result = viQueryf(vi,":MEASure:VOLTage:AC?\n","%lf",&acv);break;
		case 1:
	result = viQueryf(vi,":MEASure:VOLTage:AC? 0.1,MAX\n","%lf",&acv);break;
		case 2:
	result = viQueryf(vi,":MEASure:VOLTage:AC? 1,MAX\n","%lf",&acv);break;
		case 3:
	result = viQueryf(vi,":MEASure:VOLTage:AC? 10,MAX\n","%lf",&acv);break;
	    case 4:
	result = viQueryf(vi,":MEASure:VOLTage:AC? 100,MAX\n","%lf",&acv);break;
		case 5:
	result = viQueryf(vi,":MEASure:VOLTage:AC? 1000,MAX\n","%lf",&acv);break;
	}
	if(result == 0)
	{
		//printf("Freq =%f Hz\n",Freq);
	
	}
	else
	{
		//printf("error ,time out \n");
				//error timeout 
	}
	viClose(vi);
	viClose(defaultRM);
	return 0;

}
	double cap; 
int Getcap (void)//����
{
	int result=-1;
	viOpenDefaultRM(&defaultRM);
	viOpen(defaultRM,RESOURCE,VI_NULL,VI_NULL,&vi);
	viClear(vi);
	Initialize();
	int rangecnt_cap;//��λ������
	GetCtrlVal(panelHandle, PANEL_RING_6, &rangecnt_cap);
	switch(rangecnt_cap)
	{
		case 0:
	result = viQueryf(vi,":MEASure:CAPacitance?\n","%lf",&cap);break;	
	case 1:
	result = viQueryf(vi,":MEASure:CAPacitance? MIN,MAX\n","%lf",&cap);break;
	case 2:
	result = viQueryf(vi,":MEASure:CAPacitance? 0.00000001,MAX\n","%lf",&cap);break;
	case 3:
	result = viQueryf(vi,":MEASure:CAPacitance? 0.0000001,MAX\n","%lf",&cap);break;
	case 4:
	result = viQueryf(vi,":MEASure:CAPacitance? 0.000001,MAX\n","%lf",&cap);break;
	case 5:
	result = viQueryf(vi,":MEASure:CAPacitance? MAX,MAX\n","%lf",&cap);break; 
	}
	if(result == 0)
	{
		//printf("Freq =%f Hz\n",Freq);
	
	}
	else
	{
		//printf("error ,time out \n");
				//error timeout 
	}
	viClose(vi);
	viClose(defaultRM);
	return 0;

}
	double res;  
int Getres (void)//����
{
	int result=-1;
	viOpenDefaultRM(&defaultRM);
	viOpen(defaultRM,RESOURCE,VI_NULL,VI_NULL,&vi);
	viClear(vi);
	Initialize();
	int rangecnt_res;//��λ������
	GetCtrlVal(panelHandle, PANEL_RING_2, &rangecnt_res);
	switch(rangecnt_res)
	{
		case 0:
				result = viQueryf(vi,":MEASure:RESistance?\n","%lf",&res);break; 
		case 1:
				result = viQueryf(vi,":MEASure:RESistance? MIN,MAX\n","%lf",&res);break; 
		case 2:
				result = viQueryf(vi,":MEASure:RESistance? 1000,MAX\n","%lf",&res);break; 
		case 3:
				result = viQueryf(vi,":MEASure:RESistance? 10000,MAX\n","%lf",&res);break; 
		case 4:
				result = viQueryf(vi,":MEASure:RESistance? 100000,MAX\n","%lf",&res);break; 
		case 5:
				result = viQueryf(vi,":MEASure:RESistance? 1000000,MAX\n","%lf",&res);break; 
		case 6:
				result = viQueryf(vi,":MEASure:RESistance? 10000000\n","%lf",&res);break; 
		case 7:
				result = viQueryf(vi,":MEASure:RESistance? 100000000,MAX\n","%lf",&res);break; 
		case 8:
				result = viQueryf(vi,":MEASure:RESistance? MAX,MAX\n","%lf",&res);break; 
	}
	if(result == 0)
	{
		//printf("Freq =%f Hz\n",Freq);
	
	}
	else
	{
		//printf("error ,time out \n");
				//error timeout 
	}
	viClose(vi);
	viClose(defaultRM);
	return 0;

}

//���β����ص�
int CVICALLBACK OneShoot_CallbackFunc (int panel, int control, int event,
									   void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			int mode_f;
			GetCtrlVal(panelHandle, PANEL_RING, &mode_f);
			switch(mode_f)
			{
		case 0:Getdcv();SetCtrlVal (panelHandle, PANEL_result, dcv);break;
		case 1:Getdci();SetCtrlVal (panelHandle, PANEL_result, dci);break;
		case 2:Getacv();SetCtrlVal (panelHandle, PANEL_result, acv);break;
	    case 3:Getaci();SetCtrlVal (panelHandle, PANEL_result, aci);break;
		case 4:Getres();SetCtrlVal (panelHandle, PANEL_result, res);break;
		case 5:Getcap();SetCtrlVal (panelHandle, PANEL_result, cap);break;
		case 6:GetFreq();SetCtrlVal (panelHandle, PANEL_result, freq);break;
			}break;
	}
	return 0;
}
//���������ص�
int CVICALLBACK ContinueTest_CallbackFunc (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			Start_Stop_Flag = ~Start_Stop_Flag;

			break;
	}
	return 0;
}

//��ʱ���ص�
int CVICALLBACK TIM_Callback (int panel, int control, int event,
							  void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_TIMER_TICK:
			
			if(Start_Stop_Flag)
			{
				int mode_f;
			GetCtrlVal(panelHandle, PANEL_RING, &mode_f);
			switch(mode_f)
			{
		case 0:Getdcv();SetCtrlVal (panelHandle, PANEL_result, dcv);break;
		case 1:Getdci();SetCtrlVal (panelHandle, PANEL_result, dci);break;
		case 2:Getacv();SetCtrlVal (panelHandle, PANEL_result, acv);break;
	    case 3:Getaci();SetCtrlVal (panelHandle, PANEL_result, aci);break;
		case 4:Getres();SetCtrlVal (panelHandle, PANEL_result, res);break;
		case 5:Getcap();SetCtrlVal (panelHandle, PANEL_result, cap);break;
		case 6:GetFreq();SetCtrlVal (panelHandle, PANEL_result, freq);break;
			}
			}
			break;
	}
	return 0;
}
//����ģ�飬Ĭ����������

int cnter_config(void)//����������
{
	viOpenDefaultRM(&defaultRM);
	viOpen(defaultRM,RESOURCE,VI_NULL,VI_NULL,&vi);
	viClear(vi);
	Initialize();
	int samp_destination;//��������
			GetCtrlVal(panelHandle, PANEL_points, &samp_destination);
			viPrintf(vi,":SAMP:COUN %lf", samp_destination);
				  return 0; 
}

int timer_config(void) //��ʱ������
{
	viOpenDefaultRM(&defaultRM);
	viOpen(defaultRM,RESOURCE,VI_NULL,VI_NULL,&vi);
	viClear(vi);
	Initialize();
	double samp_Interval;//�������
	GetCtrlVal(panelHandle, PANEL_Interval, &samp_Interval);
	 viPrintf(vi,":SAMP:TIM %lf", samp_Interval); 
			return 0; 
}




int CVICALLBACK SAMPLEVOLT (int panel, int control, int event,
							void *callbackData, int eventData1, int eventData2) //��ʼ����
{
	switch (event)
	{
		case EVENT_COMMIT:
			{
			int samp_source1;
			GetCtrlVal(panelHandle, PANEL_samp_source, &samp_source1);
			switch(samp_source1)
		    case 0:cnter_config();break;
		    case 2:timer_config();break;
			viPrintf(vi,":INIT\n");
			}
		break;
	}
	return 0;
}
char samp_data1[2000]; 
char samp_data[2000];
float ydata[2000];
void drawgraph(void)//���߻���            
{
	 char delims[]=",";
	 char *tempresult = NULL;
	 tempresult = strtok(samp_data,delims);
	 int m =0;
	 int n =0;
	 while(tempresult !=NULL)
	 {
		 sprintf(samp_data1[m++],"%s",tempresult);
		 tempresult = strtok(NULL,delims);
	 }
	 for(n=0;n<m;n++)
	 {
		 ydata[n]= atof(samp_data1[n]);
	 }
}

   
int CVICALLBACK data_process (int panel, int control, int event,
							  void *callbackData, int eventData1, int eventData2)//���ݴ���
{
	switch (event)
	{
		case EVENT_COMMIT:
	viOpenDefaultRM(&defaultRM);
	viOpen(defaultRM,RESOURCE,VI_NULL,VI_NULL,&vi);
	viClear(vi);
	viQueryf(vi,":DATA:DATA?\n","%lf",&samp_data);
	drawgraph(); 
	SetCtrlAttribute(PANEL, PANEL_WAVEFORM,ATTR_REFRESH_GRAPH,0);
    DeleteGraphPlot (panelHandle, PANEL_WAVEFORM, -1, VAL_IMMEDIATE_DRAW);
	PlotY (panelHandle, PANEL_WAVEFORM, ydata, 1000, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, 1, VAL_RED); 
			//drawgraph();
			break;
	}
	return 0;
}


