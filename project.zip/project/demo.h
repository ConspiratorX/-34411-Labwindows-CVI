/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANEL                            1
#define  PANEL_COMMANDBUTTON_3            2       /* control type: command, callback function: ContinueTest_CallbackFunc */
#define  PANEL_TEXTMSG                    3       /* control type: textMsg, callback function: (none) */
#define  PANEL_rst_but                    4       /* control type: command, callback function: get_rst */
#define  PANEL_COMMANDBUTTON_2            5       /* control type: command, callback function: OneShoot_CallbackFunc */
#define  PANEL_idn_but                    6       /* control type: command, callback function: get_idn */
#define  PANEL_RING                       7       /* control type: ring, callback function: (none) */
#define  PANEL_TIMER                      8       /* control type: timer, callback function: TIM_Callback */
#define  PANEL_TEXTMSG_2                  9       /* control type: textMsg, callback function: (none) */
#define  PANEL_RING_2                     10      /* control type: ring, callback function: (none) */
#define  PANEL_RING_3                     11      /* control type: ring, callback function: (none) */
#define  PANEL_RING_4                     12      /* control type: ring, callback function: (none) */
#define  PANEL_RING_5                     13      /* control type: ring, callback function: (none) */
#define  PANEL_RING_6                     14      /* control type: ring, callback function: (none) */
#define  PANEL_SAMPLE_EN                  15      /* control type: command, callback function: SAMPLEVOLT */
#define  PANEL_WAVEFORM                   16      /* control type: strip, callback function: (none) */
#define  PANEL_result                     17      /* control type: numeric, callback function: (none) */
#define  PANEL_points                     18      /* control type: numeric, callback function: (none) */
#define  PANEL_Interval                   19      /* control type: numeric, callback function: (none) */
#define  PANEL_IDN_WINDOW                 20      /* control type: string, callback function: (none) */
#define  PANEL_COMMANDBUTTON              21      /* control type: command, callback function: data_process */
#define  PANEL_samp_source                22      /* control type: binary, callback function: (none) */
#define  PANEL_TEXTMSG_3                  23      /* control type: textMsg, callback function: (none) */
#define  PANEL_TEXTMSG_4                  24      /* control type: textMsg, callback function: (none) */


     /* Control Arrays: */

          /* (no control arrays in the resource file) */


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */

int  CVICALLBACK ContinueTest_CallbackFunc(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK data_process(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK get_idn(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK get_rst(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK OneShoot_CallbackFunc(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SAMPLEVOLT(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK TIM_Callback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif
