#include <cvirte.h>		
#include <userint.h>
#include "demo.h"


static int panelHandle;

  /*
  main()
{
	int i,quit;
	
	viOpenDefaultRM(&defaultRM);
	viOpen(defaultRM,RESOURCE,VI_NULL,VI_NULL,&vi);
	viClear(vi);
	Initialize();
	
	viClose(vi);
	viClose(defaultRM); 
	while(1)
	{
		GetAmplitude();
		GetPTPeak ();
		GetPeriod () ;
		printf("\n"); 
	}
	return ;
	
	
}*/





